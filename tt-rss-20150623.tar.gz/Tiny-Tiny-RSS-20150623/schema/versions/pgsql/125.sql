begin;

update ttrss_version set schema_version = 125;

commit;
