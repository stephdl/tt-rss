begin;

update ttrss_version set schema_version = 123;

commit;
