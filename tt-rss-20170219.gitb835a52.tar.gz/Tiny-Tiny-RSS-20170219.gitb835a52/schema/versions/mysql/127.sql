BEGIN;

UPDATE ttrss_version SET schema_version = 127;

COMMIT;
