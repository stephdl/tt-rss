dojo.addOnLoad(function() {
	updateTitle = function() {
		document.title = "Tiny Tiny RSS";
	};
});
