dojo.addOnLoad(function() {
	hash_set = function() { };
	hash_get = function() { };
});
